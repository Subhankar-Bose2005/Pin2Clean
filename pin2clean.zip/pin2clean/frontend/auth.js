const SUPABASE_URL = 'https://zkfscxfomcergpvsgrtg.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InprZnNjeGZvbWNlcmdwdnNncnRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2OTAxMDMsImV4cCI6MjA4NTI2NjEwM30.7kzAE7GHIFxUfbJ6mshFyiq5sjr3LqWf8uu9PiQ7tL4';

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Tab switching
const loginTab = document.getElementById('login-tab');
const signupTab = document.getElementById('signup-tab');
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');

loginTab.addEventListener('click', () => {
  loginTab.classList.add('active');
  signupTab.classList.remove('active');
  loginForm.classList.remove('hidden');
  signupForm.classList.add('hidden');
  clearMessages();
});

signupTab.addEventListener('click', () => {
  signupTab.classList.add('active');
  loginTab.classList.remove('active');
  signupForm.classList.remove('hidden');
  loginForm.classList.add('hidden');
  clearMessages();
});

function clearMessages() {
  document.querySelectorAll('.auth-message').forEach(el => {
    el.textContent = '';
    el.className = 'auth-message';
  });
}

function showMessage(elId, msg, type = 'error') {
  const el = document.getElementById(elId);
  el.textContent = msg;
  el.className = `auth-message ${type}`;
}

// Login
document.getElementById('login-btn').addEventListener('click', async () => {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  if (!email || !password) {
    showMessage('login-msg', 'Please fill in all fields.');
    return;
  }

  const btn = document.getElementById('login-btn');
  btn.textContent = 'Signing in…';
  btn.disabled = true;

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  btn.textContent = 'Sign In';
  btn.disabled = false;

  if (error) {
    showMessage('login-msg', error.message);
  } else {
    showMessage('login-msg', 'Success! Redirecting…', 'success');
    setTimeout(() => window.location.href = 'index.html', 800);
  }
});

// Signup
document.getElementById('signup-btn').addEventListener('click', async () => {
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;

  if (!email || !password || !confirm) {
    showMessage('signup-msg', 'Please fill in all fields.');
    return;
  }
  if (password !== confirm) {
    showMessage('signup-msg', 'Passwords do not match.');
    return;
  }
  if (password.length < 6) {
    showMessage('signup-msg', 'Password must be at least 6 characters.');
    return;
  }

  const btn = document.getElementById('signup-btn');
  btn.textContent = 'Creating account…';
  btn.disabled = true;

  const { data, error } = await supabase.auth.signUp({ email, password });

  btn.textContent = 'Create Account';
  btn.disabled = false;

  if (error) {
    showMessage('signup-msg', error.message);
  } else {
    showMessage('signup-msg', 'Account created! Check your email to confirm, then sign in.', 'success');
  }
});

// Redirect if already logged in
(async () => {
  const { data: { session } } = await supabase.auth.getSession();
  if (session) {
    window.location.href = 'index.html';
  }
})();
