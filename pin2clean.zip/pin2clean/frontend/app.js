const SUPABASE_URL = 'https://zkfscxfomcergpvsgrtg.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InprZnNjeGZvbWNlcmdwdnNncnRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2OTAxMDMsImV4cCI6MjA4NTI2NjEwM30.7kzAE7GHIFxUfbJ6mshFyiq5sjr3LqWf8uu9PiQ7tL4';
const API_BASE = 'http://localhost:8080/api';

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let map;
let currentUser = null;
let currentProfile = null;
let selectedFile = null;
let markers = [];

// ── Init ─────────────────────────────────────────────────────────────────────

async function init() {
  // Guard: must be logged in
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    window.location.href = 'login.html';
    return;
  }
  currentUser = session.user;

  // Fetch profile from backend (has role)
  try {
    const res = await apiFetch('/profile/me');
    currentProfile = await res.json();
  } catch (e) {
    console.error('Failed to load profile', e);
    currentProfile = { email: currentUser.email, role: 'CITIZEN' };
  }

  // Update UI with user info
  document.getElementById('user-email').textContent = currentProfile.email;
  const roleBadge = document.getElementById('user-role');
  roleBadge.textContent = currentProfile.role;
  roleBadge.className = `role-badge role-${currentProfile.role.toLowerCase()}`;

  // Show volunteer controls if applicable
  if (currentProfile.role === 'VOLUNTEER' || currentProfile.role === 'ADMIN') {
    document.getElementById('vol-tip').style.display = 'block';
  }

  initMap();
  await loadReports();
  setupUpload();
}

// ── Map ───────────────────────────────────────────────────────────────────────

function initMap() {
  map = L.map('map', { zoomControl: false }).setView([20, 78], 5);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
  }).addTo(map);

  L.control.zoom({ position: 'bottomright' }).addTo(map);
}

function makeIcon(emoji) {
  return L.divIcon({
    html: `<div class="map-pin">${emoji}</div>`,
    className: '',
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -20]
  });
}

async function loadReports() {
  try {
    const res = await fetch(`${API_BASE}/reports`);
    const reports = await res.json();

    // Clear old markers
    markers.forEach(m => map.removeLayer(m));
    markers = [];

    reports.forEach(r => addMarker(r));
    updateStats(reports);
  } catch (e) {
    showToast('Failed to load reports', 'error');
    console.error(e);
  }
}

function addMarker(report) {
  const emoji = report.status === 'CLEANED' ? '✅' : '🚨';
  const icon = makeIcon(emoji);
  const marker = L.marker([report.latitude, report.longitude], { icon }).addTo(map);

  const date = report.createdAt ? new Date(report.createdAt).toLocaleDateString() : 'N/A';
  const canClean = (currentProfile?.role === 'VOLUNTEER' || currentProfile?.role === 'ADMIN') && report.status === 'ACTIVE';

  const severityColor = { LOW: '#4caf50', MEDIUM: '#ff9800', HIGH: '#f44336' }[report.severity] || '#888';

  let popupHtml = `
    <div class="popup-card">
      <img src="${report.imageUrl}" alt="Report image" class="popup-img" onerror="this.style.display='none'" />
      <div class="popup-body">
        <div class="popup-status ${report.status === 'CLEANED' ? 'cleaned' : 'active'}">
          ${report.status === 'CLEANED' ? '✅ CLEANED' : '🚨 NEEDS CLEANING'}
        </div>
        <div class="popup-severity" style="color:${severityColor}">⚠ ${report.severity} severity</div>
        <p class="popup-desc">${report.description || '<em>No description</em>'}</p>
        <div class="popup-date">📅 Reported: ${date}</div>
        ${canClean ? `<button class="popup-clean-btn" onclick="markCleaned('${report.id}')">✅ Mark as Cleaned</button>` : ''}
      </div>
    </div>
  `;

  marker.bindPopup(popupHtml, { maxWidth: 260, className: 'custom-popup' });
  markers.push(marker);
}

function updateStats(reports) {
  const total = reports.length;
  const cleaned = reports.filter(r => r.status === 'CLEANED').length;
  const pending = total - cleaned;
  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-pending').textContent = pending;
  document.getElementById('stat-cleaned').textContent = cleaned;
}

// ── Upload ────────────────────────────────────────────────────────────────────

function setupUpload() {
  const uploadBox = document.getElementById('upload-box');
  const fileInput = document.getElementById('file-input');
  const preview = document.getElementById('upload-preview');

  uploadBox.addEventListener('click', () => fileInput.click());

  uploadBox.addEventListener('dragover', e => {
    e.preventDefault();
    uploadBox.classList.add('dragover');
  });

  uploadBox.addEventListener('dragleave', () => uploadBox.classList.remove('dragover'));

  uploadBox.addEventListener('drop', e => {
    e.preventDefault();
    uploadBox.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  });

  fileInput.addEventListener('change', e => {
    const file = e.target.files[0];
    if (file) handleFileSelect(file);
  });
}

async function handleFileSelect(file) {
  selectedFile = file;

  // Show image preview
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('preview-img').src = e.target.result;
    document.getElementById('upload-preview').classList.remove('hidden');
    document.getElementById('upload-placeholder').classList.add('hidden');
  };
  reader.readAsDataURL(file);

  // Extract GPS client-side with exifr for preview
  try {
    const gps = await exifr.gps(file);
    if (gps) {
      document.getElementById('gps-display').textContent =
        `📍 ${gps.latitude.toFixed(5)}, ${gps.longitude.toFixed(5)}`;
      document.getElementById('gps-status').className = 'gps-status ok';
      // Pan map to location
      map.setView([gps.latitude, gps.longitude], 14);
    } else {
      document.getElementById('gps-display').textContent = '⚠ No GPS data found in image';
      document.getElementById('gps-status').className = 'gps-status warn';
    }
  } catch (e) {
    document.getElementById('gps-display').textContent = '⚠ Could not read GPS data';
    document.getElementById('gps-status').className = 'gps-status warn';
  }
}

async function submitReport() {
  if (!selectedFile) {
    showToast('Please select an image first', 'error');
    return;
  }

  const description = document.getElementById('description').value.trim();
  const severity = document.getElementById('severity').value;

  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    showToast('Session expired, please log in again', 'error');
    window.location.href = 'login.html';
    return;
  }

  const btn = document.getElementById('submit-btn');
  const spinner = document.getElementById('upload-spinner');
  btn.disabled = true;
  btn.textContent = 'Uploading…';
  spinner.classList.remove('hidden');

  try {
    const formData = new FormData();
    formData.append('image', selectedFile);
    if (description) formData.append('description', description);
    formData.append('severity', severity);

    const res = await fetch(`${API_BASE}/reports/upload`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${session.access_token}` },
      body: formData
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Upload failed');
    }

    showToast('Report submitted successfully! 🎉', 'success');
    resetUploadForm();
    await loadReports();

    // Fly to the new pin
    map.setView([data.latitude, data.longitude], 15);

  } catch (e) {
    showToast(e.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '📤 Submit Report';
    spinner.classList.add('hidden');
  }
}

function resetUploadForm() {
  selectedFile = null;
  document.getElementById('file-input').value = '';
  document.getElementById('description').value = '';
  document.getElementById('severity').value = 'MEDIUM';
  document.getElementById('upload-preview').classList.add('hidden');
  document.getElementById('upload-placeholder').classList.remove('hidden');
  document.getElementById('gps-display').textContent = '';
  document.getElementById('gps-status').className = 'gps-status';
}

// ── Mark as Cleaned ───────────────────────────────────────────────────────────

async function markCleaned(reportId) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    showToast('Session expired', 'error');
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/reports/${reportId}/clean`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${session.access_token}` }
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Failed to mark as cleaned');
    }

    showToast('Marked as cleaned! Great work 🌿', 'success');
    map.closePopup();
    await loadReports();
  } catch (e) {
    showToast(e.message, 'error');
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

async function apiFetch(path, options = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  const headers = { ...options.headers };
  if (session) headers['Authorization'] = `Bearer ${session.access_token}`;
  return fetch(`${API_BASE}${path}`, { ...options, headers });
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

async function logout() {
  await supabase.auth.signOut();
  window.location.href = 'login.html';
}

// ── Start ─────────────────────────────────────────────────────────────────────
init();
