package com.example.pin2clean.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "reports")
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "image_url", nullable = false)
    private String imageUrl;

    @Column(name = "latitude", nullable = false)
    private Double latitude;

    @Column(name = "longitude", nullable = false)
    private Double longitude;

    @Column(name = "description")
    private String description;

    @Column(name = "severity", nullable = false)
    private String severity = "MEDIUM";

    @Column(name = "status", nullable = false)
    private String status = "ACTIVE";

    @Column(name = "reported_by")
    private UUID reportedBy;

    @Column(name = "cleaned_by")
    private UUID cleanedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "cleaned_at")
    private LocalDateTime cleanedAt;

    public Report() {}

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public UUID getReportedBy() { return reportedBy; }
    public void setReportedBy(UUID reportedBy) { this.reportedBy = reportedBy; }

    public UUID getCleanedBy() { return cleanedBy; }
    public void setCleanedBy(UUID cleanedBy) { this.cleanedBy = cleanedBy; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getCleanedAt() { return cleanedAt; }
    public void setCleanedAt(LocalDateTime cleanedAt) { this.cleanedAt = cleanedAt; }
}
