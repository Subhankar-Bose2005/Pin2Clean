package com.example.pin2clean.controller;

import com.example.pin2clean.model.Profile;
import com.example.pin2clean.repository.ProfileRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    private final ProfileRepository profileRepository;

    public ProfileController(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    /**
     * GET /api/profile/me
     * Returns the current authenticated user's profile (including role).
     */
    @GetMapping("/me")
    public ResponseEntity<?> getMyProfile(@AuthenticationPrincipal Jwt jwt) {
        try {
            UUID userId = UUID.fromString(jwt.getSubject());
            return profileRepository.findById(userId)
                    .map(ResponseEntity::ok)
                    .orElseGet(() -> {
                        // Return a basic profile if not in DB yet (shouldn't happen with trigger)
                        Profile fallback = new Profile();
                        fallback.setId(userId);
                        fallback.setEmail(jwt.getClaimAsString("email"));
                        fallback.setRole("CITIZEN");
                        return ResponseEntity.ok(fallback);
                    });
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Failed to fetch profile: " + e.getMessage());
            return ResponseEntity.internalServerError().body(error);
        }
    }
}
