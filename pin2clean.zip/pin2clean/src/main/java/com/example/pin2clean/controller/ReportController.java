package com.example.pin2clean.controller;

import com.example.pin2clean.model.Report;
import com.example.pin2clean.service.ReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * POST /api/reports/upload
     * Upload a geotagged image and create a report.
     * Requires authentication.
     */
    @PostMapping("/upload")
    public ResponseEntity<?> uploadReport(
            @RequestParam("image") MultipartFile image,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "severity", defaultValue = "MEDIUM") String severity,
            @AuthenticationPrincipal Jwt jwt
    ) {
        try {
            UUID userId = UUID.fromString(jwt.getSubject());
            Report report = reportService.createReport(image, description, severity, userId);
            return ResponseEntity.status(HttpStatus.CREATED).body(report);
        } catch (IllegalArgumentException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Failed to upload report: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * GET /api/reports/active
     * Returns all ACTIVE (dirty) reports. Public endpoint.
     */
    @GetMapping("/active")
    public ResponseEntity<List<Report>> getActiveReports() {
        return ResponseEntity.ok(reportService.getActiveReports());
    }

    /**
     * GET /api/reports
     * Returns all reports. Public endpoint.
     */
    @GetMapping
    public ResponseEntity<List<Report>> getAllReports() {
        return ResponseEntity.ok(reportService.getAllReports());
    }

    /**
     * GET /api/reports/{id}
     * Returns a single report. Public endpoint.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getReport(@PathVariable UUID id) {
        return reportService.getReportById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * PUT /api/reports/{id}/clean
     * Marks a report as cleaned. Requires VOLUNTEER or ADMIN role (checked in service).
     */
    @PutMapping("/{id}/clean")
    public ResponseEntity<?> markCleaned(
            @PathVariable UUID id,
            @AuthenticationPrincipal Jwt jwt
    ) {
        try {
            UUID userId = UUID.fromString(jwt.getSubject());
            Report report = reportService.markCleaned(id, userId);
            return ResponseEntity.ok(report);
        } catch (SecurityException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(error);
        } catch (IllegalArgumentException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Failed to mark as cleaned: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}
