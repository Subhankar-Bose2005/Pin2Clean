package com.example.pin2clean.service;

import com.example.pin2clean.model.Profile;
import com.example.pin2clean.model.Report;
import com.example.pin2clean.repository.ProfileRepository;
import com.example.pin2clean.repository.ReportRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ReportService {

    private final ReportRepository reportRepository;
    private final ProfileRepository profileRepository;
    private final ExifService exifService;
    private final StorageService storageService;

    public ReportService(
            ReportRepository reportRepository,
            ProfileRepository profileRepository,
            ExifService exifService,
            StorageService storageService
    ) {
        this.reportRepository = reportRepository;
        this.profileRepository = profileRepository;
        this.exifService = exifService;
        this.storageService = storageService;
    }

    public Report createReport(MultipartFile image, String description, String severity, UUID userId) throws Exception {
        // Extract GPS from EXIF server-side
        double[] gps = exifService.extractGps(image);
        if (gps == null) {
            throw new IllegalArgumentException("No GPS data found in image EXIF metadata. Please upload a geotagged photo.");
        }

        // Upload image to Supabase Storage
        String imageUrl = storageService.uploadImage(image);

        // Build and save report
        Report report = new Report();
        report.setImageUrl(imageUrl);
        report.setLatitude(gps[0]);
        report.setLongitude(gps[1]);
        report.setDescription(description);
        report.setSeverity(severity != null ? severity : "MEDIUM");
        report.setStatus("ACTIVE");
        report.setReportedBy(userId);
        report.setCreatedAt(LocalDateTime.now());

        return reportRepository.save(report);
    }

    public List<Report> getActiveReports() {
        return reportRepository.findByStatus("ACTIVE");
    }

    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

    public Optional<Report> getReportById(UUID id) {
        return reportRepository.findById(id);
    }

    public Report markCleaned(UUID reportId, UUID cleanerUserId) {
        // Verify user is VOLUNTEER or ADMIN
        Optional<Profile> profileOpt = profileRepository.findById(cleanerUserId);
        if (profileOpt.isEmpty()) {
            throw new SecurityException("User profile not found.");
        }
        String role = profileOpt.get().getRole();
        if (!"VOLUNTEER".equals(role) && !"ADMIN".equals(role)) {
            throw new SecurityException("Only VOLUNTEER or ADMIN can mark reports as cleaned.");
        }

        Report report = reportRepository.findById(reportId)
                .orElseThrow(() -> new IllegalArgumentException("Report not found: " + reportId));

        report.setStatus("CLEANED");
        report.setCleanedBy(cleanerUserId);
        report.setCleanedAt(LocalDateTime.now());

        return reportRepository.save(report);
    }
}
