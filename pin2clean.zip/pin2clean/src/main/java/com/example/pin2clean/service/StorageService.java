package com.example.pin2clean.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.UUID;

@Service
public class StorageService {

    private final WebClient webClient;
    private final String supabaseUrl;
    private final String serviceKey;

    public StorageService(
            @Value("${supabase.url}") String supabaseUrl,
            @Value("${supabase.service-key}") String serviceKey
    ) {
        this.supabaseUrl = supabaseUrl;
        this.serviceKey = serviceKey;
        this.webClient = WebClient.builder()
                .baseUrl(supabaseUrl)
                .build();
    }

    /**
     * Uploads the file to Supabase Storage bucket "report-images".
     * Returns the public URL of the uploaded file.
     */
    public String uploadImage(MultipartFile file) throws Exception {
        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        String contentType = file.getContentType() != null ? file.getContentType() : "image/jpeg";

        webClient.post()
                .uri("/storage/v1/object/report-images/" + fileName)
                .header("Authorization", "Bearer " + serviceKey)
                .header("apikey", serviceKey)
                .contentType(MediaType.parseMediaType(contentType))
                .body(BodyInserters.fromResource(new org.springframework.core.io.ByteArrayResource(file.getBytes()) {
                    @Override
                    public String getFilename() {
                        return fileName;
                    }
                }))
                .retrieve()
                .bodyToMono(String.class)
                .block();

        // Return the public URL
        return supabaseUrl + "/storage/v1/object/public/report-images/" + fileName;
    }
}
