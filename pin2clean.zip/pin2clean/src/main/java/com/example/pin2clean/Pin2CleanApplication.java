package com.example.pin2clean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pin2CleanApplication {

    public static void main(String[] args) {
        SpringApplication.run(Pin2CleanApplication.class, args);
    }
}
