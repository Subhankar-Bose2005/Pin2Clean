package com.example.pin2clean.service;

import com.drew.imaging.ImageMetadataReader;
import com.drew.lang.GeoLocation;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.GpsDirectory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Collection;

@Service
public class ExifService {

    /**
     * Extracts GPS coordinates from a multipart image file.
     * Returns a double[] of {latitude, longitude}, or null if not found.
     */
    public double[] extractGps(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            Metadata metadata = ImageMetadataReader.readMetadata(inputStream);
            Collection<GpsDirectory> gpsDirs = metadata.getDirectoriesOfType(GpsDirectory.class);

            for (GpsDirectory gpsDirectory : gpsDirs) {
                GeoLocation geoLocation = gpsDirectory.getGeoLocation();
                if (geoLocation != null && !geoLocation.isZero()) {
                    return new double[]{geoLocation.getLatitude(), geoLocation.getLongitude()};
                }
            }
        } catch (Exception e) {
            // Log and fall through to return null
            System.err.println("Failed to extract GPS from EXIF: " + e.getMessage());
        }
        return null;
    }
}
